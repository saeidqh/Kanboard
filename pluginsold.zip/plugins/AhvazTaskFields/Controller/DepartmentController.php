<?php

namespace Kanboard\Plugin\AhvazTaskFields\Controller;

use Kanboard\Controller\BaseController;
use Kanboard\Core\Controller\AccessForbiddenException;

class DepartmentController extends BaseController
{
    public function index()
    {
        $project = $this->getProject();
        $this->checkAccess($project['id']);

        $departments = $this->departmentModel->getAllByProject($project['id'], false);

        $this->response->html($this->helper->layout->project('AhvazTaskFields:department/index', array(
            'project'     => $project,
            'departments' => $departments,
            'title'       => t('Departments') . ' — ' . $project['name'],
        )));
    }

    public function create(array $values = array(), array $errors = array())
    {
        $project = $this->getProject();
        $this->checkAccess($project['id']);

        if (empty($values)) {
            $values = array('project_id' => $project['id'], 'is_active' => 1);
        }

        $this->response->html($this->template->render('AhvazTaskFields:department/create', array(
            'project' => $project,
            'values'  => $values,
            'errors'  => $errors,
        )));
    }

    public function save()
    {
        $project = $this->getProject();
        $this->checkAccess($project['id']);

        $values = $this->request->getValues();
        $values['project_id'] = $project['id'];
        $values['is_active'] = isset($values['is_active']) ? 1 : 0;

        if (empty(trim(isset($values['name']) ? $values['name'] : ''))) {
            $this->create($values, array('name' => array(t('This field is required'))));
            return;
        }

        $id = $this->departmentModel->create($values);

        if ($id) {
            $this->flash->success(t('Department created successfully.'));
        } else {
            $this->flash->failure(t('Unable to create this department.'));
        }

        $this->response->redirect($this->helper->url->to('DepartmentController', 'index', array(
            'plugin'     => 'AhvazTaskFields',
            'project_id' => $project['id'],
        )));
    }

    public function edit(array $values = array(), array $errors = array())
    {
        $project = $this->getProject();
        $this->checkAccess($project['id']);

        $departmentId = $this->request->getIntegerParam('department_id');
        $department = $this->departmentModel->getById($departmentId);

        if (empty($department) || (int)$department['project_id'] !== (int)$project['id']) {
            $this->flash->failure(t('Department not found.'));
            $this->response->redirect($this->helper->url->to('DepartmentController', 'index', array(
                'plugin' => 'AhvazTaskFields', 'project_id' => $project['id'],
            )));
            return;
        }

        if (empty($values)) {
            $values = $department;
        }

        $this->response->html($this->template->render('AhvazTaskFields:department/edit', array(
            'project'     => $project,
            'department'  => $department,
            'values'      => $values,
            'errors'      => $errors,
        )));
    }

    public function update()
    {
        $project = $this->getProject();
        $this->checkAccess($project['id']);

        $values = $this->request->getValues();
        $values['id'] = $this->request->getIntegerParam('department_id');
        $values['is_active'] = isset($values['is_active']) ? 1 : 0;

        $department = $this->departmentModel->getById($values['id']);
        if (empty($department) || (int)$department['project_id'] !== (int)$project['id']) {
            $this->flash->failure(t('Department not found.'));
            $this->response->redirect($this->helper->url->to('DepartmentController', 'index', array(
                'plugin' => 'AhvazTaskFields', 'project_id' => $project['id'],
            )));
            return;
        }

        if (empty(trim(isset($values['name']) ? $values['name'] : ''))) {
            $this->edit($values, array('name' => array(t('This field is required'))));
            return;
        }

        if ($this->departmentModel->update($values)) {
            $this->flash->success(t('Department updated successfully.'));
        } else {
            $this->flash->failure(t('Unable to update this department.'));
        }

        $this->response->redirect($this->helper->url->to('DepartmentController', 'index', array(
            'plugin'     => 'AhvazTaskFields',
            'project_id' => $project['id'],
        )));
    }

    public function remove()
    {
        $project = $this->getProject();
        $this->checkAccess($project['id']);
        $this->checkCSRFParam();

        $departmentId = $this->request->getIntegerParam('department_id');
        $department = $this->departmentModel->getById($departmentId);

        if (!empty($department) && (int)$department['project_id'] === (int)$project['id']) {
            if ($this->departmentModel->remove($departmentId)) {
                $this->flash->success(t('Department removed successfully.'));
            } else {
                $this->flash->failure(t('Unable to remove this department.'));
            }
        }

        $this->response->redirect($this->helper->url->to('DepartmentController', 'index', array(
            'plugin'     => 'AhvazTaskFields',
            'project_id' => $project['id'],
        )));
    }

    public function json()
    {
        $project = $this->getProject();
        $list = $this->departmentModel->getAllByProject($project['id'], true);
        $result = array();
        foreach ($list as $row) {
            $result[] = array('id' => $row['name'], 'text' => $row['name']);
        }
        $this->response->json(array('results' => $result));
    }

    /**
     * Allow if:
     * - app admin
     * - has HierarchicalRoles module "departments"
     * - OR has module "org_structure"
     */
    protected function checkAccess($projectId)
    {
        if ($this->userSession->isAdmin()) {
            return;
        }

        $helper = isset($this->helper->hierarchicalRoleHelper) ? $this->helper->hierarchicalRoleHelper : null;

        if ($helper && is_object($helper) && method_exists($helper, 'canAccessModule')) {
            if ($helper->canAccessModule($projectId, 'departments')) {
                return;
            }
            if ($helper->canAccessModule($projectId, 'org_structure')) {
                return;
            }
        }

        throw new AccessForbiddenException();
    }
}
