<?php

namespace Kanboard\Plugin\AhvazTaskFields\Subscriber;

use Kanboard\Event\GenericEvent;
use Kanboard\Model\TaskModel;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Kanboard\Core\Base;

class TaskSubscriber extends Base implements EventSubscriberInterface
{
    public static function getSubscribedEvents()
    {
        return [
            TaskModel::EVENT_CREATE => 'afterSave',
            TaskModel::EVENT_UPDATE => 'afterSave',
        ];
    }

    /**
     * Ensure definition_of_done is persisted
     * (core TaskModel may ignore unknown columns depending on version)
     */
    public function afterSave(GenericEvent $event)
    {
        $taskId = $event['task_id'] ?? ($event['task']['id'] ?? null);
        if (!$taskId) {
            return;
        }

        $values = $this->request->getValues();

        if (array_key_exists('definition_of_done', $values)) {
            $this->db->table(TaskModel::TABLE)
                ->eq('id', $taskId)
                ->update(['definition_of_done' => $values['definition_of_done']]);
        }
    }
}
