(function () {
    'use strict';

    var LABEL_MAP = {
        1: 'Document number',
        2: 'Reference',
        3: 'Letter number',
        4: 'MOM number',
        5: 'Department'
    };

    // CSS selectors for known task form fields
    var FIELD_SELECTORS = {
        complexity:     ['#form-complexity', 'input[name="complexity"]', 'label[for="form-complexity"]'],
        score:          ['#form-score', 'input[name="score"]', 'label[for="form-score"]'],
        time_estimated: ['#form-time_estimated', 'input[name="time_estimated"]', 'label[for="form-time_estimated"]'],
        time_spent:     ['#form-time_spent', 'input[name="time_spent"]', 'label[for="form-time_spent"]'],
        date_due:       ['#form-date_due', 'input[name="date_due"]', 'label[for="form-date_due"]'],
        date_started:   ['#form-date_started', 'input[name="date_started"]', 'label[for="form-date_started"]'],
        priority:       ['#form-priority', 'select[name="priority"]', 'label[for="form-priority"]'],
        color_id:       ['#form-color_id', 'select[name="color_id"]', 'label[for="form-color_id"]'],
        tags:           ['input[name="tags"]', 'label[for="form-tags"]', '.tag-autocomplete']
    };

    function hideElementAndGroup(el) {
        if (!el) return;
        el.style.display = 'none';
        el.classList.add('ahvaz-field-hidden');
        // climb parents that look like form groups
        var p = el.parentElement;
        for (var i = 0; i < 5 && p; i++) {
            var cls = (p.className || '').toString();
            if (cls.indexOf('form-group') !== -1 || cls.indexOf('form-column') !== -1 ||
                p.querySelectorAll('input,select,textarea,label').length <= 3) {
                // only hide if this parent is mostly about this field
                var hasOtherVisible = false;
                // simple: hide form-group style parents
                if (cls.indexOf('form-group') !== -1 || cls.indexOf('form-column') !== -1) {
                    p.style.display = 'none';
                    p.classList.add('ahvaz-field-hidden');
                    break;
                }
            }
            // Also: if parent only contains this input + label
            p = p.parentElement;
        }
    }

    function hideField(fieldKey) {
        var selectors = FIELD_SELECTORS[fieldKey];
        if (!selectors) {
            // generic fallback
            selectors = [
                '#form-' + fieldKey,
                'input[name="' + fieldKey + '"]',
                'select[name="' + fieldKey + '"]',
                'textarea[name="' + fieldKey + '"]',
                'label[for="form-' + fieldKey + '"]'
            ];
        }
        selectors.forEach(function (sel) {
            document.querySelectorAll(sel).forEach(hideElementAndGroup);
        });

        // label text match fallback for Complexity
        if (fieldKey === 'complexity') {
            document.querySelectorAll('label').forEach(function (lab) {
                if (lab.textContent && /complexity/i.test(lab.textContent)) {
                    hideElementAndGroup(lab);
                    var g = lab.closest('.form-group, .form-column, p, div');
                    if (g) {
                        g.style.display = 'none';
                        g.classList.add('ahvaz-field-hidden');
                    }
                }
            });
        }
    }

    function applyVisibility(map) {
        Object.keys(map).forEach(function (key) {
            if (map[key] === false || map[key] === 0 || map[key] === '0') {
                hideField(key);
            }
        });
        // Always try hide complexity if not explicitly shown
        if (map.complexity === false || map.complexity === 0 || typeof map.complexity === 'undefined') {
            // if undefined, still hide complexity as product default
            hideField('complexity');
        }
    }

    function loadVisibilityAndApply() {
        var projectId = (document.getElementById('ahvaz-project-id') || {}).value;
        var formKey = (document.getElementById('ahvaz-form-key') || {}).value || 'task_create';

        // Always hide complexity immediately (don't wait for AJAX)
        hideField('complexity');

        if (!projectId) {
            return;
        }

        var url = '?controller=FormFieldController&action=visibilityJson&plugin=AhvazTaskFields&project_id=' +
                  encodeURIComponent(projectId) + '&form_key=' + encodeURIComponent(formKey);

        fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (data) {
                if (data && data.visibility) {
                    applyVisibility(data.visibility);
                }
            })
            .catch(function () {
                hideField('complexity');
            });
    }

    // ===== Reference / Department logic (same as before) =====
    function getCategorySelect() {
        return document.getElementById('form-category_id') ||
               document.querySelector('select[name="category_id"]');
    }
    function getReferenceInput() {
        return document.getElementById('form-reference') ||
               document.querySelector('input[name="reference"]');
    }
    function getReferenceLabel() {
        var input = getReferenceInput();
        if (!input) return null;
        var label = document.querySelector('label[for="form-reference"]');
        if (!label && input.id) label = document.querySelector('label[for="' + input.id + '"]');
        if (!label) {
            var c = input.closest('.form-group, .form-column, div');
            if (c) label = c.querySelector('label');
        }
        return label;
    }
    function setRequired(el, required) {
        if (!el) return;
        if (required) el.setAttribute('required', 'required');
        else el.removeAttribute('required');
    }
    function updateReferenceField() {
        var catSelect = getCategorySelect();
        var refInput  = getReferenceInput();
        var refLabel  = getReferenceLabel();
        if (!catSelect || !refInput) return;

        var catId = parseInt(catSelect.value, 10) || 0;
        var labelText = LABEL_MAP[catId] || 'Reference';
        if (refLabel) refLabel.innerHTML = labelText + ' <span style="color:#c00;">*</span>';
        setRequired(refInput, catId >= 1 && catId <= 5);

        if (catId === 5) convertToDepartmentSelect(refInput);
        else convertToNormalInput(refInput);
    }
    function convertToDepartmentSelect(refInput) {
        if (refInput.dataset.ahvazMode === 'select2') return;
        var projectId = (document.getElementById('ahvaz-project-id') || {}).value;
        if (!projectId) return;

        var select = document.createElement('select');
        select.name = 'reference';
        select.id = 'form-reference';
        select.setAttribute('required', 'required');
        select.style.width = '100%';

        var currentVal = refInput.value || ((document.getElementById('ahvaz-current-reference') || {}).value || '');
        if (currentVal) {
            var opt = document.createElement('option');
            opt.value = currentVal; opt.textContent = currentVal; opt.selected = true;
            select.appendChild(opt);
        }
        refInput.parentNode.insertBefore(select, refInput);
        refInput.style.display = 'none';
        refInput.removeAttribute('name');
        refInput.dataset.ahvazMode = 'hidden';
        select.dataset.ahvazMode = 'select2';

        if (typeof jQuery !== 'undefined' && jQuery.fn.select2) {
            jQuery(select).select2({
                placeholder: 'Select a department...',
                allowClear: true,
                width: '100%',
                ajax: {
                    url: '?controller=DepartmentController&action=json&plugin=AhvazTaskFields&project_id=' + projectId,
                    dataType: 'json', delay: 200,
                    processResults: function (d) { return d; }, cache: true
                },
                minimumInputLength: 0
            });
            jQuery.ajax({
                url: '?controller=DepartmentController&action=json&plugin=AhvazTaskFields&project_id=' + projectId,
                dataType: 'json'
            }).done(function (data) {
                if (data && data.results) {
                    data.results.forEach(function (item) {
                        jQuery(select).append(new Option(item.text, item.id, false, item.id === currentVal));
                    });
                    jQuery(select).trigger('change');
                }
            });
        }
    }
    function convertToNormalInput(refInput) {
        var select = document.querySelector('select[name="reference"][data-ahvaz-mode="select2"]');
        if (select) {
            if (typeof jQuery !== 'undefined' && jQuery.fn.select2) {
                try { jQuery(select).select2('destroy'); } catch (e) {}
            }
            if (select.parentNode) select.parentNode.removeChild(select);
        }
        refInput.style.display = '';
        refInput.setAttribute('name', 'reference');
        refInput.dataset.ahvazMode = 'text';
    }

    function init() {
        loadVisibilityAndApply();
        updateReferenceField();
        var cat = getCategorySelect();
        if (cat) cat.addEventListener('change', updateReferenceField);
        setTimeout(function () {
            loadVisibilityAndApply();
            updateReferenceField();
        }, 400);
        setTimeout(loadVisibilityAndApply, 1000);
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();

    document.addEventListener('change', function (e) {
        if (e.target && (e.target.id === 'form-category_id' || e.target.name === 'category_id')) {
            updateReferenceField();
        }
    });
})();
