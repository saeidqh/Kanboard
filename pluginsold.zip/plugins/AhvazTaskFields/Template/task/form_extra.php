<?php
$definitionOfDone = isset($values['definition_of_done']) ? $values['definition_of_done'] : '';
$reference        = isset($values['reference']) ? $values['reference'] : '';
$categoryId       = isset($values['category_id']) ? (int)$values['category_id'] : 0;
$projectId        = isset($project['id']) ? (int)$project['id'] : (isset($values['project_id']) ? (int)$values['project_id'] : 0);

// Visibility map from DB
$visibility = array();
if (isset($this->formFieldModel) || method_exists($this->app, 'formFieldModel')) {
    // helper path
}
try {
    $ffm = new \Kanboard\Plugin\AhvazTaskFields\Model\FormFieldModel($this->container ?? null);
} catch (\Exception $e) {
    $ffm = null;
}
// Safer: use helper if registered - inject via JSON from a data attribute built in controller is hard on hook.
// We'll output a script that reads from a JSON endpoint OR embed map via PHP if model available through helper.

$visJson = '{}';
if (isset($this->helper->taskFieldHelper)) {
    // optional
}
?>

<div class="form-column ahvaz-field-definition_of_done">
    <label for="form-definition_of_done">
        <?= t('Definition of Done') ?> <span style="color:#c00;">*</span>
    </label>
    <?= $this->form->textarea(
        'definition_of_done',
        $values,
        $errors,
        array(
            'rows'        => 3,
            'required'    => 'required',
            'placeholder' => t('What must be true for this task to be considered done?'),
            'tabindex'    => '3',
            'id'          => 'form-definition_of_done',
        )
    ) ?>
    <p class="form-help"><?= t('This field is mandatory. Describe the acceptance criteria / Definition of Done.') ?></p>
</div>

<input type="hidden" id="ahvaz-project-id" value="<?= $projectId ?>">
<input type="hidden" id="ahvaz-current-category" value="<?= $categoryId ?>">
<input type="hidden" id="ahvaz-current-reference" value="<?= $this->text->e($reference) ?>">
<input type="hidden" id="ahvaz-form-key" value="task_create">
