<?php
$value = '';
if (!empty($values['id'])) {
    $raw = $this->task->taskMetadataModel->get($values['id'], 'manual_progress', '');
    if ($raw !== null && $raw !== '') {
        $value = (int) $raw;
    }
} elseif (isset($values['manual_progress']) && $values['manual_progress'] !== '') {
    $value = (int) $values['manual_progress'];
}
?>
<label for="form-manual_progress"><?= t('Progress') ?> (%)</label>
<input type="number"
       name="manual_progress"
       id="form-manual_progress"
       min="0"
       max="100"
       step="1"
       value="<?= $value !== '' ? $value : '' ?>"
       placeholder="0-100"
       class="form-numeric">
<p class="form-help"><?= t('Optional. Self-reported progress. Moving to Done sets 100%%.') ?></p>
