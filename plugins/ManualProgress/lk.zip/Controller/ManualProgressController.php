<?php

namespace Kanboard\Plugin\ManualProgress\Controller;

use Kanboard\Controller\BaseController;
use Kanboard\Plugin\ManualProgress\Plugin;

class ManualProgressController extends BaseController
{
    /**
     * Save progress from sidebar / AJAX / prompt modal
     */
    public function save()
    {
        $task = $this->getTask();
        $values = $this->request->getValues();
        $pct = isset($values['manual_progress']) ? (int) $values['manual_progress'] : $this->request->getIntegerParam('manual_progress', -1);

        if ($pct < 0 || $pct > 100) {
            if ($this->request->isAjax()) {
                $this->response->json(array('ok' => false, 'message' => t('Progress must be between 0 and 100')), 400);
                return;
            }
            $this->flash->failure(t('Progress must be between 0 and 100'));
            $this->response->redirect($this->helper->url->to('TaskViewController', 'show', array('task_id' => $task['id'], 'project_id' => $task['project_id'])));
            return;
        }

        $this->taskMetadataModel->save($task['id'], array(
            Plugin::META_PROGRESS => (string) $pct,
            Plugin::META_PROMPT   => '0',
        ));

        if ($this->request->isAjax()) {
            $this->response->json(array(
                'ok' => true,
                'task_id' => (int) $task['id'],
                'progress' => $pct,
            ));
            return;
        }

        $this->flash->success(t('Progress updated'));
        $this->response->redirect($this->helper->url->to('TaskViewController', 'show', array('task_id' => $task['id'], 'project_id' => $task['project_id'])));
    }

    /**
     * Small modal body used when a task leaves Done and needs a new percentage
     */
    public function prompt()
    {
        $task = $this->getTask();
        $this->response->html($this->template->render('ManualProgress:task/prompt', array(
            'task' => $task,
            'title' => t('Enter progress percentage'),
        )));
    }
}
